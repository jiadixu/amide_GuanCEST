function [FitResult, FitParam] = PLOF(Offset, Saturation, FitParam)
% Fit the Z-spectrum using polynomial and Lorentzian line-shape fitting (PLOF) method

% If you have used this function in a scientific publication,we would
% appreciate citations to the following papers:

% [1]	Chen L, Wei Z, Cai S, Li Y, Liu G, Lu H, Weiss RG, van Zijl PCM, Xu
% J. High-resolution creatine mapping of mouse brain at 11.7 T using
% non-steady-state chemical exchange saturation transfer. NMR Biomed
% 2019:e4168. 
% [2]	Chen L, Barker PB, Weiss RG, van Zijl PCM, Xu J.
% Creatine and phosphocreatine mapping of mouse skeletal muscle by a
% polynomial and Lorentzian line-shape fitting CEST method. Magn Reson Med
% 2019;81(1):69-78. 
% [3]	Chen L, Zeng H, Xu X, Yadav NN, Cai S, Puts NA,
% Barker PB, Li T, Weiss RG, van Zijl PCM, Xu J. Investigation of the
% contribution of total creatine to the CEST Z-spectrum of brain using a
% knockout mouse model. NMR Biomed 2017;30(12):e3834.
% [4]

% Please contact Kexin Wang at kwang101@jhu.edu if you have any questions about the code. 


warning off
if size(Offset,1) == 1
    Offset = Offset';
end

if size(Saturation, 1) == 1
    Saturation = Saturation';
end

if (Saturation(1)) > 10
    error('Z-spectrum have to be 0-1, can not be percentage')
end


[Offset, Saturation] = Extract_Zspectrum(Offset, Saturation, FitParam.WholeRange);
[Offset_background, Saturation_background] = CutOff_Zspectrum(Offset, Saturation, FitParam.PeakRange);

FitResult.Offset = Offset;
FitResult.Saturation = Saturation;
FitResult.Offset_background = Offset_background;
FitResult.Saturation_background = Saturation_background;

%-----------------------------------------------%
%-------------- Two-step fitting ---------------%
%-----------------------------------------------%

FitResult.xindex = linspace(min(Offset), max(Offset), 100)';

x0 = [0.1, 1, 0.5, -19, ...
        0.1, 1, 3.5, ...
        0.1, 1, 2];
lb = [0, 0, 0, -100,...
        1e-8, 0.001, 3, ...
        1e-8, 0.01, 1];
ub = [10, 100, 100, 0, ...
            10, 2, 4, ...
            10, 2, 3];
        
%-------------background fitting --------------%

FitParam.peak = 0;

options = optimset('MaxFunEvals', 1e6,'TolFun', 1e-6,'TolX', 1e-6, 'Display',  'off' );
[FitResult.Coefficents, resnorm] = lsqcurvefit(@CurveFunction, x0, Offset_background, Saturation_background, lb, ub, options, FitParam);

% fitting result of Z-spectrum and R-spectrum
[FitResult.Background, Rbak] = CurveFunction(FitResult.Coefficents, FitResult.xindex, FitParam);
Backgroundtmp = CurveFunction(FitResult.Coefficents, Offset, FitParam);
FitResult.DeltaZspectrum = Backgroundtmp - Saturation; 

% R^2 for the evaluation of fitting
FitResult.RsquareBG = 1 - goodnessOfFit(CurveFunction(FitResult.Coefficents, Offset_background, FitParam), Saturation_background, 'NMSE');

%   fitted background at 3.5 ppm
tmplist = abs(FitResult.xindex - 3.5);
[res,  idx] = min(tmplist);
FitResult.MTbackground = FitResult.Background(idx); 

%-------------CEST all-peak fitting --------------%
FitParam.peak = 1;

% fix the background parameters
lb(1: 4) = FitResult.Coefficents(1 : 4); 
ub(1: 4) = FitResult.Coefficents(1 : 4); 

[FitResult.Coefficents, resnorm] = lsqcurvefit(@CurveFunction, x0, Offset, Saturation, lb, ub, options, FitParam);
[FitResult.Curve, Rtmp] = CurveFunction(FitResult.Coefficents, FitResult.xindex, FitParam);

FitResult.DeletaFitZ = FitResult.Background-FitResult.Curve;
FitResult.DeletaFitR = Rtmp - Rbak;


%------------ Calculate deltaZ and assign the Coefficents ---------------%

FitResult.Rpeak1 = FitResult.Coefficents(5);
FitResult.FitPeakOffset1 = FitResult.Coefficents(7);
FitResult.Rpeak2 = FitResult.Coefficents(8);
FitResult.FitPeakOffset2 = FitResult.Coefficents(10); 

FitResult.MT = FitResult.Coefficents(1); 
FitResult.RsquareAll = 1 - goodnessOfFit(CurveFunction(FitResult.Coefficents, Offset, FitParam), Saturation, 'NMSE');


%------------ Calculate DeltaZ-spectrum ---------------%

% amide peak
FitParam.peak = 2;

[Ztmp Rtmp]= CurveFunction(FitResult.Coefficents, FitResult.xindex, FitParam); 
FitResult.ZamideFit =FitResult.Background -Ztmp;
[FitResult.DeltaZpeak1,  idx]= max(FitResult.ZamideFit);
FitResult.DeltaZpeak1Offset = FitResult.xindex(idx); 
FitResult.RamideFit =Rtmp - Rbak;
[FitResult.DeltaRpeak1, idx] = max(FitResult.RamideFit);
FitResult.DeltaRpeak1Offset = FitResult.xindex(idx); 

% guan peak
FitParam.peak = 3;

[Ztmp Rtmp] = CurveFunction(FitResult.Coefficents, FitResult.xindex, FitParam); 
FitResult.ZguanFit =FitResult.Background -Ztmp;
[FitResult.DeltaZpeak2,  idx] = max(FitResult.ZguanFit);
FitResult.DeltaZpeak2Offset = FitResult.xindex(idx); 
FitResult.RguanFit =Rtmp - Rbak;
[FitResult.DeltaRpeak2,  idx] = max(FitResult.RguanFit);
FitResult.DeltaRpeak2Offset = FitResult.xindex(idx); 

%------------ modify FitResult.SNR ---------------%
if FitParam.CalSNR == 1
    sample = FitParam.SNRimg;
    SNRmask = FitParam.SNRmask;

    signal = mean(sample(SNRmask));

    [M, N] = size(sample);
    maskCorners = zeros(M, N);
    t = 16; % ensure the sum of 4 squares in the corner >= 1000 pixels
    maskCorners(1:t, 1:t) = 1;
    maskCorners(1:t, N - t + 1: N) = 1;
    maskCorners(M - t + 1: M, 1:t) = 1;
    maskCorners(M - t + 1: M, N - t + 1: N) = 1;
    noise = std(sample(logical(maskCorners)));
    FitResult.SNR = signal/noise;
end


      if FitParam.ifshowimage == 1
            PlotFitResult(FitResult,FitParam);
      end
end
function normailzed_imgs = Normalize_cestimgs(original_imgs)

for i = 1:size(IMGtmp,3) % decide how many rows (offset)
        img = IMGtmp(:, :, i); % which dimension?
       for itube =1: size(ROI, 3)
         ROItmp=ROI(:,:,itube); % extract itube_th tube  
          CEST(i, itube+1) = mean(img(ROItmp));  
%           CESTSTD(i, itube+1) = std(img(ROItmp));  
        end
end
  
 scaler = zeros(1, tube);
for itube = 1:size(ROI, 3)
     CESTM0(:, itube+1) = CEST(:, itube + 1)./CEST(2, itube + 1); 
     scaler(itube) = CEST(2, itube+1);
%      CESTstd(:,itube+1) = CESTSTD(:,itube+1)./(CESTSTD(2,itube+1) ^2); 
end


% Scale and check
for i = 1: size(IMGtmp, 3) % decide how many rows (offset)        
       for itube =1: size(ROI, 3)
           img = IMGtmp(:, :, i); 
         ROItmp = ROI(:, :, itube); % extract itube_th tube  
         img = img./ scaler(itube);
         sCEST(i, itube+1) = mean(img(ROItmp));  
         sCESTSTD(i, itube+1) = std(img(ROItmp));  
        end
end
 

end